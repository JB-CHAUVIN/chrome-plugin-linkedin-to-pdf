chrome.tabs.captureVisibleTab()
