# LinkedIn : Convert profile to PDF
## This chrome extension will allow you to convert your LinkedIn profile into a downlodable PDF file.

Introducing our Chrome plugin, designed to help you easily create stunning PDFs of your LinkedIn profiles without any unwanted elements. With our plugin, you can say goodbye to the hassle of maintaining two separate CVs.

Our plugin seamlessly removes all unwanted elements from your LinkedIn profile and generates a beautiful PDF that respects the design of the LinkedIn CSS page. This ensures that your PDF looks professional and is visually consistent with your LinkedIn profile.

With just a few clicks, you can convert your LinkedIn profile into a PDF that you can print, save or share with others. Whether you're a job seeker or simply looking to create a professional-looking CV, our plugin has got you covered.

Save time and effort by using our Chrome plugin and take the first step towards creating a beautiful and professional-looking LinkedIn profile. Install our plugin today and see the difference for yourself!
